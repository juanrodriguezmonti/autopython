from .presenter import Presenter

__version__ = (0, 7)

VERSION = '.'.join(str(d) for d in __version__)
